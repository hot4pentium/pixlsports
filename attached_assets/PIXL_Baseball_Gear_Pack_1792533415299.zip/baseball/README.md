# PIXL Baseball gear

Four independent realistic transparent PNG assets. Keep aspect ratios and use object-fit: contain. Canvas dimensions vary; manifest.json lists dimensions and visible alpha bounds for consistent sizing. Uniform colors are baked in; add names and numbers as separate layers. These are standalone showcase objects rather than pose-aligned avatar overlays.
