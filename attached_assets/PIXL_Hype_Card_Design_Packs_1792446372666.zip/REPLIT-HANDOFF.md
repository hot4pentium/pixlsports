# PIXL Sports — six hype card design packs

These are clean, code-native recreations of the concept sheet, rather than pixel-exact extractions. No athlete photos or fonts are included.

## Files
Each style folder includes frame.svg/png, lower-third.svg/png, combined-overlay.svg/png, and preview.svg/png. All files share a 900 × 1200 canvas. Transparent areas have real alpha. Lower-thirds retain the full canvas for perfect alignment; do not auto-trim their blank top area. Combined overlays are convenience files: use either the combined overlay OR the two independent pieces.

## Layer order
1. Parent-uploaded photo, full bleed, object-fit: cover.
2. Lower third, absolute inset: 0, width and height 100%.
3. Frame, same positioning.
4. Editable name, position, jersey number. Coordinates in manifest.json use the SVG coordinate system and text baselines.

Wrap in position: relative; aspect-ratio: 3 / 4; overflow: hidden. Use a 4.5% border radius for Wave, Glass and Spotlight, and clip-path: polygon(4% 0,96% 0,100% 3%,100% 97%,96% 100%,4% 100%,0 97%,0 3%) for Velocity, Varsity and Pixel Edge. Assets must scale together without independent offsets. Keep photo controls separate from overlay controls.

## Colors and effects
Use SVG sources for team-color editing. Blue #087DFF, navy #061A38, cyan #00D9F5, lime #BAF500, cream #F4E9CC, gold #D8B35A. Replace fills and strokes using a parsed SVG or inline React SVG with CSS variables; external img SVG does not inherit page CSS variables. Namespace SVG gradient IDs per rendered card to prevent collisions. PNG colors are fixed.

Glass uses translucent white rather than baked-in blur. Optional backdrop-filter blur can be applied to a matching HTML panel for live viewing; SVG/PNG exports retain predictable translucency. Spotlight intentionally fades from transparent to opaque at the bottom.

## Editable text
Use an overlaid SVG viewBox="0 0 900 1200" for consistent text baselines. Default family: sans-serif, bold name; varsity can use a separately licensed collegiate font. Fit long names to 590 units, then reduce font size or use two lines. Escape user text. Do not place text inside image assets. Keep number in the right column. Handle missing numbers by hiding that field. Parent should be able to pan/zoom photo and select frame and lower third independently.

## Export
Rasterize photo + selected SVG layers + editable text to one 900 × 1200 PNG (or 1800 × 2400). Wait for images and fonts to load. Ensure uploaded photos are same-origin or CORS-enabled to avoid canvas taint. Test at mobile width and with long names, dark/light uniforms and all six combinations. Keep important feet/equipment above the lower third via photo reposition controls.
