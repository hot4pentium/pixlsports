# 04-varsity

Transparent frame and lower-third supplied separately as SVG and PNG. All assets are 900 × 1200 (3:4). Align at x=0, y=0 at identical dimensions. Preview is a placeholder only; do not ship it as the athlete image. Name, position, and number are deliberately absent from production layers. See root REPLIT-HANDOFF.md and manifest.json.
